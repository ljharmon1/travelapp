package edu.bumgarner.jacktravel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class atwater extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atwater);
    }
}
